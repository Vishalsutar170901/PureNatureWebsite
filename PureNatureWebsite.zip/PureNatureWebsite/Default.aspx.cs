﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            LoadCategory();
            if(Request.QueryString["id"]!=null)
            {
                hdfCatID.Value = Request.QueryString["id"].ToString();
                LoadProducts();
            }
        }
    }
    private void LoadCategory()
    {
        try
        {
            string strcmd = "select CatID,CatName from Categories order by CatName";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            DataList1.DataSource = dt;
            DataList1.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if(e.CommandName== "CatName")
        {
            HiddenField hdf = (HiddenField)e.Item.FindControl("HiddenField1");
            Response.Redirect("~/Default.aspx?id=" + hdf.Value);

        }
    }
    private void LoadProducts()
    {
        try
        {
            string strcmd = "Select * from Products where CatID=" + hdfCatID.Value;
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            DataList2.DataSource = dt;
            DataList2.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if(e.CommandName=="Cart")
        {
            HiddenField id = (HiddenField)e.Item.FindControl("hdfProductID");
            HiddenField price = (HiddenField)e.Item.FindControl("hdfPrice");

            string strcmd = "insert into Cart(ProductID,Dated,Price,Qty,UserID) values(" + id.Value + ",'" +
                DateTime.Now.ToString("yyyy-MM-dd") + "'," + price.Value + ",1," + Session["UserID"].ToString() + ")";
            SQLHelper.ExecuteNonQuery(strcmd);
            MasterPage1 m = (MasterPage1)this.Master;
            m.LoadCart();
        }
    }
}