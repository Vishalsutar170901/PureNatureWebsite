﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        try
        {
            string strcmd = "Select UserID,RoleID,UPassword,FullName,Active " +
                "from Users where UserName='" + txtUsername.Text + "'";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            if (dt.Rows.Count > 0)
            {
                bool Active = Convert.ToBoolean(dt.Rows[0]["Active"]);
                if (Active == true)

                {
                    string strPassword = dt.Rows[0]["UPassword"].ToString();
                    if (txtpassword.Text == strPassword)
                    {
                        Session["UserID"] = dt.Rows[0]["UserID"].ToString();
                        Session["RoleID"] = dt.Rows[0]["RoleID"].ToString();
                        Session["FullName"] = dt.Rows[0]["FullName"].ToString();
                        if (Session["RoleID"].ToString() == "1")
                        {
                            Response.Redirect("~/Admin/Default.aspx");
                        }
                        if (Session["RoleID"].ToString() == "2")
                        {
                            Response.Redirect("~/HomePage.aspx");
                        }
                    }
                    else
                    {
                        lblMsg.Text = "Invalid Password!!!";
                    }
                }
                else
                {
                    lblMsg.Text = "Account is suspended";
                }

            }
            else
            {
                lblMsg.Text = "Invalid Username!!!";


            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}

    


    
