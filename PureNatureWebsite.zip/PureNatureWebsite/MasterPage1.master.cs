﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class MasterPage1 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            LoadCart();
        }

        if (Session["RoleID"].ToString() != "2")
        {
            Response.Redirect("~/Default2.aspx");//Login page
        }
        if (!Page.IsPostBack)
        {
            lblUserName.Text = Session["FullName"].ToString();
        }
    }
    public void LoadCart()
    {
        try
        {
            string strcmd = "select count(CartID) from Cart where UserID=" + Session["UserID"].ToString();
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            if(dt.Rows.Count>0)
            {
                hlkCart.Text = "(" + dt.Rows[0][0].ToString() + ")";
            }
            else
            {
                hlkCart.Text = "(0)";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
