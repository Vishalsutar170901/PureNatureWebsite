﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        try
        {
            string strcmd = "Select UserID from Users where UserName='" + txtUsername.Text + "'";
            DataTable dt = new DataTable();
            dt = SQLHelper.FillData(strcmd);
            if (dt.Rows.Count > 0)
            {
                lblMsg.Text = "Username is already taken,try other name";
                txtUsername.Focus();

            }
            else
            {
                strcmd = "insert into Users(UserName,RoleID,UPassword,FullName,SecQue,SecAns,Dated,Active)" +
                "values('" + txtUsername.Text + "',2,'" + tbPass.Text + "','" + SQLHelper.sf(tbFullname.Text) + "','" +
                SQLHelper.sf(txtSecque.Text) + "','" + SQLHelper.sf(txtans.Text) + "','" +
                DateTime.Now.ToString("yyyy-MM-dd") + "',1)";
                SQLHelper.ExecuteNonQuery(strcmd);
                Response.Redirect("~/success.aspx");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }

    
}
}